Version 1 of the Ansible Tower REST API.

Make a GET request to this resource to obtain a list of all child resources
available via the API.
